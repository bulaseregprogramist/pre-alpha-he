import unittest


class HouseEscapeTest(unittest.TestCase):
    
    def testMath(self):
        pass
    
    
def main() -> None:
    het = HouseEscapeTest()
    het.run()
    
    
if __name__ == "__main__":
    main()
    

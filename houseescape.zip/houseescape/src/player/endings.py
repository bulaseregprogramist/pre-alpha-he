"""Концовки игры HouseEscape"""


class Endings:
    """Основной функционал концовок"""
    
    def identify_ending(self) -> None:
        """Определение на какую концовку прошёл игрок"""
        pass

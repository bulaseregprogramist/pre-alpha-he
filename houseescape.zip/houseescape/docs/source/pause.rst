Пауза во время игры
==================================
.. autoclass:: src.draw.pause.Pause
    :members:
    :private-members:
    :no-index:
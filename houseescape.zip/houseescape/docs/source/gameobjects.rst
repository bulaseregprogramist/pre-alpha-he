Мебель, предметы
================
Абстрактный класс
------------------------------------------------
.. automodule:: src.gameobjects.gameobjects
    :members:
Предметы
------------------------------------------------
.. automodule:: src.gameobjects.item
    :members:
Мебель
------------------------------------------------
.. automodule:: src.gameobjects.blocks
    :members:
    
Ловушки в игре
==================================
.. autoclass:: src.traps.traps.Traps
    :members:
    :private-members:
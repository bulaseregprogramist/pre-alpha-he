Отрисовка локаций, предметов
===================================
Отрисовка локаций
-------------------------------------
.. autoclass:: src.draw.draw.Draw
    :members:
    
Отрисовка главного меню
-------------------------------------
.. autoclass:: src.draw.mainmenu.MainMenu
    :members:
    :private-members:
    
Отрисовка меню паузы
-------------------------------------
.. autoclass:: src.draw.pause.Pause
    :members:
    :private-members:
    

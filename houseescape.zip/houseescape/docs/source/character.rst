Персонажи и всё, что с ними связано
============================================
Персонаж
------------------------------------------------
.. autoclass:: src.player.character.Character
    :members:
Движение
------------------------------------------------
.. automodule:: src.player.move
    :members:
Игрок
------------------------------------------------
.. automodule:: src.player.player
    :members:
Враги
------------------------------------------------
.. autoclass:: src.player.enemys.Enemy
    :members:
Концовки
-----------------------------------------------
.. autoclass:: src.player.endings.Endings
    :members:
    
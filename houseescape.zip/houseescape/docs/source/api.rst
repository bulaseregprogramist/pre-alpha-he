API игры, необходимое для модов
===================================

.. autoclass:: src.api.api.HEAPI
    :members:
    :private-members: